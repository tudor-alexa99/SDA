#include "RandomTest.h"
#include "SortedSet.h"
#include <iostream>

using namespace std;

void RandomTest::randomTest()
{
	DynamicVector<TComp> gion{};
	gion.add(3);
	gion.add(4);
	gion.add(6);
	gion.insert(2, 0);
	//cout << gion.getElems();
	

}