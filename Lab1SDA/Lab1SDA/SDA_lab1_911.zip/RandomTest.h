#pragma once
#include "DynamicVector.h"

class RandomTest
{
public:
	RandomTest();
	~RandomTest();
	void randomTest();

};

