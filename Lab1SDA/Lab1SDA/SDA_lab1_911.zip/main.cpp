#include "RandomTest.h"
#include "ShortTest.h"
#include <Windows.h>
int main()
{
	RandomTest t;
	//t.randomTest();
	system("pause");
	testAll();
}


RandomTest::RandomTest()
{
}


RandomTest::~RandomTest()
{
}
